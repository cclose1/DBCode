TRUNCATE TABLE Provider;
TRUNCATE TABLE Addresses;
TRUNCATE TABLE Address;
TRUNCATE TABLE Contact;
TRUNCATE TABLE Contacts;
TRUNCATE TABLE Contacts;
TRUNCATE TABLE Services;
TRUNCATE TABLE Coverage;

SELECT * FROM accrm.coverage;
SELECT * FROM accrm.services;
SELECT * FROM accrm.contact;
SELECT * FROM accrm.contacts;
SELECT * FROM accrm.provider;