
DROP VIEW IF EXISTS Spend;
DROP VIEW IF EXISTS SpendTransactions;
DROP VIEW IF EXISTS CurrentAccount;
DROP VIEW IF EXISTS BankTransactions;

DROP TABLE IF EXISTS Currency;

CREATE TABLE Currency (
	Designation VARCHAR(10) NOT NULL,
	Symbol      VARCHAR(3)  NULL,
	Description VARCHAR(1000),
	PRIMARY KEY (Designation ASC)
);

DROP TABLE IF EXISTS Bank;

CREATE TABLE Bank(
	Code          VARCHAR(20) NOT NULL,
	Bank          VARCHAR(20) NOT NULL,
	SortCode      VARCHAR(8)  NOT NULL,
	PRIMARY KEY (Code  ASC)
); 

DROP TABLE IF EXISTS BankTransactionType;

CREATE TABLE BankTransactionType(
	Code    VARCHAR(20) NOT NULL,
	Created DATETIME    DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (Code  ASC)
);

DROP TABLE IF EXISTS CurrencyRate;

CREATE TABLE CurrencyRate(
	Created  DATETIME NOT NULL   DEFAULT CURRENT_TIMESTAMP,
	Source   VARCHAR(4)  NOT NULL,
	Target   VARCHAR(4)  NOT NULL,
	Provider VARCHAR(20),
	Rate     FLOAT(6),
	PRIMARY KEY (
		Created ASC,
		Source  ASC,
		Target  ASC)
);

DROP TABLE IF EXISTS AccountUsage;

CREATE TABLE AccountUsage(
	Code    VARCHAR(20) NOT NULL,
	Created DATETIME    DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY (Code  ASC)
);

DROP TABLE IF EXISTS Account;

CREATE TABLE Account(
	Start         DATETIME    NOT NULL,
	End           DATETIME    NULL,
	Code          VARCHAR(4)  NOT NULL,
	Bank          VARCHAR(4)  NOT NULL,
	AccountNumber VARCHAR(30) NULL,
	Type          VARCHAR(10) NOT NULL,
	CardNumber    VARCHAR(20) NULL,
	CardType      VARCHAR(20) NULL,
	Owner         VARCHAR(20) NULL,
	Description   VARCHAR(50) NULL,
	PRIMARY KEY (Start ASC, Code ASC)
); 
DROP TABLE IF EXISTS SpendData;

CREATE TABLE SpendData (
  SeqNo          int(11)       NOT NULL AUTO_INCREMENT,
  Modified       Datetime(3)   DEFAULT NULL, 
  IncurredBy     VARCHAR(20)   DEFAULT 'Chris',
  Timestamp      datetime(3)   DEFAULT NULL,
  Category       varchar(20)   DEFAULT NULL,
  Type           varchar(20)   DEFAULT NULL,
  Description    varchar(1000) DEFAULT NULL,
  Location       varchar(1000) DEFAULT NULL,
  Amount         decimal(10,2) DEFAULT NULL,
  Monthly        char(1)       DEFAULT NULL,
  `Ignore`       char(1)       DEFAULT NULL,
  Period         char(1)       DEFAULT NULL,
  Payment        varchar(30)   DEFAULT NULL,
  BankCorrection decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (SeqNo)
);

DELIMITER //

CREATE TRIGGER InsSpendData BEFORE INSERT ON SpendData
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

CREATE TRIGGER UpdSpendData BEFORE UPDATE ON SpendData
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

DELIMITER ;

DROP TABLE IF EXISTS  TransactionHeader;

CREATE TABLE TransactionHeader(
	SeqNo         INT              NOT NULL AUTO_INCREMENT,
	Created       DATETIME         NULL,
	Modified      DATETIME         NULL, 
	TXNId         VARCHAR(15)      NULL,	
	Description   VARCHAR(1000)    NULL,
	CONSTRAINT PKTransactionHeader PRIMARY KEY CLUSTERED(
		SeqNo  ASC)
);

ALTER TABLE TransactionHeader AUTO_INCREMENT=1000;

DELIMITER //

CREATE TRIGGER InsTransactionHeader BEFORE INSERT ON TransactionHeader
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

CREATE TRIGGER UpdTransactionHeader BEFORE UPDATE ON TransactionHeader
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

DELIMITER ;

DROP TABLE IF EXISTS TransactionLine;

CREATE TABLE TransactionLine(
    TXNId         VARCHAR(15)     NOT NULL,
    Line          INT(11)         NOT NULL,
	Modified      DATETIME        NULL, 
	Timestamp     DATETIME        NULL,
	Completed     DATETIME        NULL,
	Account       VARCHAR(4),
	Amount        decimal(20, 13) NULL,
	Fee           decimal(20, 13) NULL,
	Currency      VARCHAR(4),
    Type          VARCHAR(15),
    `Usage`       VARCHAR(10),
	CryptoAddress VARCHAR(50),
	Description   VARCHAR(1000),
	CONSTRAINT PKTransactionLine PRIMARY KEY CLUSTERED(
		TXNId  ASC,
        Line   ASC)
);

DELIMITER //

CREATE TRIGGER InsTransactionLine BEFORE INSERT ON TransactionLine
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

CREATE TRIGGER UpdTransactionLine BEFORE UPDATE ON TransactionLine
FOR EACH ROW
BEGIN
	SET NEW.Modified = COALESCE(NEW.Modified, NOW());
END;//

DELIMITER ;

CREATE VIEW Spend AS 
SELECT 
	SeqNo,
	Modified,
	IncurredBy,
	Timestamp,
	CAST(Timestamp AS Date)        AS Date,
	CAST(Timestamp AS Time)        AS Time,
	Year(Timestamp)                AS Year,
	Month(Timestamp)               AS Month,
	DayOfMonth(Timestamp)          AS Day,
	Week(Timestamp,0)              AS Week,
	SUBSTR(DAYNAME(Timestamp),1,3) AS Weekday,
	CASE
		WHEN DAYOFWEEK(Timestamp) = 2 THEN DAYOFYEAR(Timestamp)
		WHEN DAYOFWEEK(Timestamp) = 3 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -1 DAY))
		WHEN DAYOFWEEK(Timestamp) = 4 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -2 DAY))
		WHEN DAYOFWEEK(Timestamp) = 5 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -3 DAY))
		WHEN DAYOFWEEK(Timestamp) = 6 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -4 DAY))
		WHEN DAYOFWEEK(Timestamp) = 7 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -5 DAY))
		WHEN DAYOFWEEK(Timestamp) = 1 THEN DAYOFYEAR(DATE_ADD(Timestamp, INTERVAL -6 DAY))
		ELSE -1
	END FirstWeekday,
	Category,
	Type,
	Amount,
	Description,
	Location,
	Period,
	`Ignore`,
	Payment,
	IFNULL(BankCorrection, '') AS BankCorrection
from SpendData;

CREATE VIEW CurrentAccount
AS
SELECT
	*
FROM Account
WHERE CURRENT_TIMESTAMP BETWEEN Start AND IFNULL(End, '3000-01-01');

CREATE VIEW BankTransactions
AS
SELECT
	TL.TXNId,
    THL.Start      AS TXNCreated,
    TH.Description AS TXNDescription,
    TL.Line,
	TL.Timestamp,
    TL.Completed,
	BK.Bank,
	BK.SortCode,
	TL.Account,
    TL.Fee,
	AC.AccountNumber,
	AC.CardNumber,
	AC.Description AS AccountDescription,
	TL.Amount,
	TL.Currency,
    TL.Type,
    TL.`Usage`,
    TL.CryptoAddress,
	TL.Description
FROM TransactionLine TL
LEFT JOIN Account    AC
ON   TL.Account    = AC.Code
AND  TL.Timestamp  BETWEEN AC.Start AND IFNULL(End, '01-Jan-3000')
LEFT JOIN Bank       BK
ON   AC.Bank       = BK.Code
LEFT JOIN TransactionHeader TH
ON TL.TXNId = TH.TXNId
LEFT JOIN (
	SELECT
		TXNId,
		Min(Timestamp) AS Start
	FROM TransactionLine
	GROUP BY TXNId) THL
ON TL.TXNId = THL.TXNId;

CREATE VIEW SpendTransactions
AS
SELECT
	SD.SeqNo, 
	SD.Timestamp,
	SD.Description,
	SD.Location,
	SD.Amount,
	SD.Payment                               AS PaymentCode,
	SD.Amount + IFNULL(SD.BankCorrection, 0) AS BankAmount,
	IFNULL(SD.BankCorrection ,0)             AS Correction,
	PS.Type,
	BK.Bank,
	BK.SortCode,
	AC.AccountNumber,
	AC.CardNumber,
	AC.Owner
FROM SpendData          SD
LEFT JOIN PaymentSource PS
ON   SD.Payment       = PS.Code
LEFT JOIN Account       AC
ON   PS.Account       = AC.Code
LEFT JOIN Bank          BK
ON   AC.Bank          = BK.Code
WHERE Payment <> 'Cash';

